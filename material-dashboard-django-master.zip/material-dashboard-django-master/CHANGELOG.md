# Change Log

## [1.0.1] 2021-02-10
### Improvements

- Bump UI: [Jinja Material](https://github.com/app-generator/jinja-material-dashboard) v1.0.2
- Bump Codebase: [Django Dashboard](https://github.com/app-generator/boilerplate-code-django-dashboard) v1.0.4

### 2017-06-20 - Bug Fix
Left menu selection based on the current page. Modified files:
- app\views.py
- core\templates\includes\sidebar-rtl.html

## [1.0.0] 2020-07-30
### Initial Release
